<?php
return [
    'name'          => 'Edugator - Teachify LMS theme',
    'description'   => 'Beautiful LMS theme that covers your needs, Powered By Teachify LMS',
    'url'           => 'https://themeqx.com',
    'author'        => 'Themeqx',
    'author_url'    => 'https://themeqx.com',
    'version'       => '1.0.0',
];

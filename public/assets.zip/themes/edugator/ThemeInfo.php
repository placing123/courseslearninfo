<?php
return [
    'name'          => 'PieInfo Academy',
    'description'   => 'Beautiful LMS theme that covers your needs, Powered PieInfo Academy LMS',
    'url'           => 'http://pieinfoacademy.in',
    'author'        => 'PieInfo Academy',
    'author_url'    => 'http://pieinfoacademy.in',
    'version'       => '1.0.0',
];
